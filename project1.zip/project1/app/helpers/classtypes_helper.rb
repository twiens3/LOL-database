module ClasstypesHelper
end
