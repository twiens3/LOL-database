module ClassTypesHelper
end
