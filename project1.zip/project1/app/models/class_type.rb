class ClassType < ApplicationRecord
end
