class Place < ApplicationRecord
  has_many :characters
  validates :location, presence: true
  validates :numberofchamps, numericality: true


end
