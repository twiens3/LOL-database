class Character < ApplicationRecord
  has_one :place
  validates :name, presence: true
  validates :classtype, presence: true
end
