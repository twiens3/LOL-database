# This file should ensure the existence of records required to run the application in every environment (production,
# development, test). The code here should be idempotent so that it can be executed at any point in every environment.
# The data can then be loaded with the bin/rails db:seed command (or created alongside the database with db:setup).
#
# Example:
#
#   ["Action", "Comedy", "Drama", "Horror"].each do |genre_name|
#     MovieGenre.find_or_create_by!(name: genre_name)
#   end
require 'csv'
Character.destroy_all
Place.destroy_all
csv= Rails.root.join('db/LoL-Champions.csv')
data= File.read(csv)

characters = CSV.parse(data, headers: true)

13.times do
  Place.create(location: Faker::Games::LeagueOfLegends.unique.location, numberofchamps: 0 )
end

characters.each do |character|
  Character.create(champ_id: character[0],name: character[1],classtype: character[2],style: character[3],difficulty: character[4],damagetype: character[5],damage: character[6],sturdiness: character[7],crowd_control: character[8],mobility: character[9],functionality: character[10], location: Faker::Games::LeagueOfLegends.location )
end

Place.find_each do |place|
  char = Character.where(location: place.location).count
  place.update(numberofchamps: char)
end




