class Addlocationtocharacter < ActiveRecord::Migration[7.2]
  def change
  end
end
