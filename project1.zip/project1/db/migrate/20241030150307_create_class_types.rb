class CreateClassTypes < ActiveRecord::Migration[7.2]
  def change
    create_table :class_types do |t|
      t.string :classtype
      t.integer :numberofchamps

      t.timestamps
    end
  end
end
