class CreateCharacters < ActiveRecord::Migration[7.2]
  def change
    create_table :characters do |t|
      t.string :champ_id
      t.string :name
      t.string :classtype
      t.string :style
      t.string :difficulty
      t.string :damagetype
      t.string :damage
      t.string :sturdiness
      t.string :crowd_control
      t.string :mobility
      t.string :functionality
      t.string :location

      t.timestamps
    end
  end
end
