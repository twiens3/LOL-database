require "test_helper"

class ChampionTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
