require "application_system_test_case"

class ClasstypesTest < ApplicationSystemTestCase
  setup do
    @classtype = classtypes(:one)
  end

  test "visiting the index" do
    visit classtypes_url
    assert_selector "h1", text: "Classtypes"
  end

  test "should create classtype" do
    visit classtypes_url
    click_on "New classtype"

    fill_in "Classtype", with: @classtype.classtype
    fill_in "Numberofchamps", with: @classtype.numberofchamps
    click_on "Create Classtype"

    assert_text "Classtype was successfully created"
    click_on "Back"
  end

  test "should update Classtype" do
    visit classtype_url(@classtype)
    click_on "Edit this classtype", match: :first

    fill_in "Classtype", with: @classtype.classtype
    fill_in "Numberofchamps", with: @classtype.numberofchamps
    click_on "Update Classtype"

    assert_text "Classtype was successfully updated"
    click_on "Back"
  end

  test "should destroy Classtype" do
    visit classtype_url(@classtype)
    click_on "Destroy this classtype", match: :first

    assert_text "Classtype was successfully destroyed"
  end
end
