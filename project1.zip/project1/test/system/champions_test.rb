require "application_system_test_case"

class ChampionsTest < ApplicationSystemTestCase
  setup do
    @champion = champions(:one)
  end

  test "visiting the index" do
    visit champions_url
    assert_selector "h1", text: "Champions"
  end

  test "should create champion" do
    visit champions_url
    click_on "New champion"

    fill_in "Classtype", with: @champion.classtype
    fill_in "Crowd-control", with: @champion.crowd-control
    fill_in "Damage", with: @champion.damage
    fill_in "Damagetype", with: @champion.damagetype
    fill_in "Difficulty", with: @champion.difficulty
    fill_in "Location", with: @champion.location
    fill_in "Mobility", with: @champion.mobility
    fill_in "Name", with: @champion.name
    fill_in "Sturdiness", with: @champion.sturdiness
    fill_in "Style", with: @champion.style
    click_on "Create Champion"

    assert_text "Champion was successfully created"
    click_on "Back"
  end

  test "should update Champion" do
    visit champion_url(@champion)
    click_on "Edit this champion", match: :first

    fill_in "Classtype", with: @champion.classtype
    fill_in "Crowd-control", with: @champion.crowd-control
    fill_in "Damage", with: @champion.damage
    fill_in "Damagetype", with: @champion.damagetype
    fill_in "Difficulty", with: @champion.difficulty
    fill_in "Location", with: @champion.location
    fill_in "Mobility", with: @champion.mobility
    fill_in "Name", with: @champion.name
    fill_in "Sturdiness", with: @champion.sturdiness
    fill_in "Style", with: @champion.style
    click_on "Update Champion"

    assert_text "Champion was successfully updated"
    click_on "Back"
  end

  test "should destroy Champion" do
    visit champion_url(@champion)
    click_on "Destroy this champion", match: :first

    assert_text "Champion was successfully destroyed"
  end
end
